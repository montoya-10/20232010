<?php
    
header('location: start/start.php');

?>