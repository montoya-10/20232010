<?php
    
    include ("./php/funciones.php");
    $usuario=$_GET['usuario'];
    echo borrarusuario($usuario);
    echo "<br>";

    echo direcciones('start.php','inicio');


?>