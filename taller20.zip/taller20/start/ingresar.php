<?php
    
    include("./php/funciones.php");

    echo direcciones('start.php','volver');
    echo "<br>";
    echo direcciones('registrar.php','registrate');
    echo "<br>";
    echo ingresar('usuario.php','patricia','patico');
    echo "<br>";
    
  
   
?>