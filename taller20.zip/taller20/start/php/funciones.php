<?php
    
//-----------------------------------------------------------------------------------------------
//aqui van a ir las funciones--------------------------------------------------------------------

//aqui va la base de datos-----------------------------------------------------------------------
/*
*@return texto aqui se retorna la conexion-------------------------------------------------------
*/
function obtenerconexion(){

    $conexion= new mysqli('localhost','root','root','faster');

    return $conexion;


}


//aqui termina la base de datos------------------------------------------------------------------

//aqui van las direcciones-----------------------------------------------------------------------
/*
*@param texto este parametro sirve para dar una direccion
*@param texto este parametro sirve para darle el titulo al enlace
@return texto este return retorna la variable salida
*/
function direcciones($direccion,$nombre){

$salida= "<a href='$direccion'>$nombre</a>";

return $salida;


}
//aqui termina las direcciones---------------------------------------------------------------------

//aqui va la funcion ingresar usuario--------------------------------------------------------------

function ingresar($direccion,$usuario,$contraseña){
$conexion=obtenerconexion();

$salida = null;

$sql="select * from usuarios where usuario='$usuario' and password='$contraseña'";

$resultado=$conexion->query($sql);

if($resultado==true){

    if($resultado->num_rows>0){
       
        while($fila=$resultado->fetch_assoc()){

            $nombre=$fila['nombres'];
            $email=$fila['email'];

        }
        $conexion->close();

        header('location: '.$direccion.'?usuario='.$usuario);

    }else{

        $salida='los datos son incorrectos';
    }



}else{

    $salida='la consulta no se realizo';
}
return $salida;

}

//aqui comienza la funcion borrar usuario---------------------------------------------------------------------
/*
* @param texto este parametro trae al usuario por url---------------------------------------------------------
* @return texto retorna la variable salida--------------------------------------------------------------------
*/
function borrarusuario($usuario){

$conexion=obtenerconexion();

$salida= null;

$sql="delete from usuarios where usuario='$usuario'";

$resultado=$conexion->query($sql);

if($resultado==true){

    $salida='el usuario a sido borrado';


}else{

    $salida='salio mal el borrado';
}
return $salida;

}

//aqui termina la funcion borrar  usuario---------------------------------------------------------------------


//aqui comienza la funcion conteo ---------------------------------------------------------------------

function conteo(){

 $conexion=obtenerconexion();

 $salida=null;

 $sql="select count(*) as conteo from usuarios";

 $resultado=$conexion->query($sql);

 if($resultado==true){
   $fila=$resultado->fetch_array();
    $salida='el conteo fue exitoso: '.$fila['conteo'];
    

 }else{

    $salida='esta mal, arreglalo';
 }
 return $salida;


}




//aqui termina la funcion conteo---------------------------------------------------------------------



//aqui comieza mostrar toda la tabla---------------------------------------------------------------------

function mostrar(){

$conexion=obtenerconexion();

$salida=null;

$sql="select * from usuarios";

$resultado=$conexion->query($sql);

if($resultado==true){

    while($fila=$resultado->fetch_array()){

        $salida.=$fila['idusuario']. ' '. $fila['nombres']. ' '. $fila['usuario']. ' '. 
        $fila['email']. ' '. $fila['password']. ' '. $fila['numero']. ' '.$fila['id_cargo'];
        $salida.="<br>";

    }

}
return $salida;

}


//aqui termina mostrar toda la tabla---------------------------------------------------------------------


//aqui comienza mostrar un usuario---------------------------------------------------------------------

function unusuario($usuario){

    $conexion=obtenerconexion();

    $salida=null;

    $sql="select * from usuarios where usuario='$usuario'";

    $resultado=$conexion->query($sql);

    if($resultado==true){

       
        while($fila=$resultado->fetch_assoc()){

            $salida.=$fila['idusuario']. ' '. $fila['nombres']. ' '. $fila['usuario']. ' '. 
            $fila['email']. ' '. $fila['password']. ' '. $fila['numero']. ' '.$fila['id_cargo'];
            $salida.="<br>";
    
        }

    }else{

        $salida='no fue correcto';

    }

    return $salida;


}

//aqui termina mostrar un usuario---------------------------------------------------------------------

?>

