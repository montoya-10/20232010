registrate
<br>

<?php
    

    include ("./php/funciones.php");

echo direcciones('start.php','volver');

echo "<br>";

echo direcciones('ingresar.php','ingresar');

?>