<?php
    
include("./php/funciones.php");

 echo direcciones('ingresar.php','ingresar');

echo "<br>";

 echo conteo();

 echo "<br>";

 echo mostrar();

 $direccion = 'ingresar.php';
