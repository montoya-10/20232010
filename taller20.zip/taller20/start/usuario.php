<?php
    
    include ('./php/funciones.php');

    echo direcciones('start.php','cerrar');

    echo "<br>";

    $usuario= $_GET['usuario'];

    echo direcciones('borrar.php?usuario='.$usuario,'delete');
    echo "<br>";
    echo unusuario($usuario);
?>